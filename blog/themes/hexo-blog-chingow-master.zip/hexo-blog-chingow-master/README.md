# hexo-blog-chingow

  [![Node version](https://img.shields.io/badge/node-10.15.3-blue.svg)]()  [![NPM version](https://img.shields.io/badge/npm%20package-6.4.1-brightgreen.svg)]()  [![Hexo version](https://img.shields.io/badge/hexo-3.8.0-blue.svg)](http://hexo.io)  [![Next version](https://img.shields.io/badge/Next-7.1.0-brightgreen.svg)]()  [![License](https://img.shields.io/npm/l/1.svg)]() 

#### Blog 依赖Node环境，基于 Hexo + NexT 的主题
``` 
node  10.15.3 
npm   6.4.1 
hexo  3.8.0
next  7.1.0 
```
#### 站在巨人的肩膀上才能看得更远，欢迎访问我的博客 [https://www.chingow.cn](https://www.chingow.cn)
```
写作很难
实践➕️写作更难
当你做到之后
你会觉得
你的收获对得起你的付出
```

## License
MIT	
