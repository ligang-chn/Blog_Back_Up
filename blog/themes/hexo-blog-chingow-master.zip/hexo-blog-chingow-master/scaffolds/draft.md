---
title: {{ title }}
copyright: true
related_posts: true
categories: 
tags: 
date: {{ date }}
---
